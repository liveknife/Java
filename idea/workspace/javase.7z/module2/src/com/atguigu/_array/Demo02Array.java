package com.atguigu._array;

public class Demo02Array {
    public static void main(String[] args) {

        //定义一个数组
        String[] arr1 = {"迪迦奥特曼","猫和老鼠","花园宝宝","海绵宝宝","圣斗士","百变小樱魔术卡","熊出没"};
        int len = arr1.length;
        System.out.println("len = " + len);
    }
}
