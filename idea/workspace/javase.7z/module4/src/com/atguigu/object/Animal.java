package com.atguigu.object;

public class Animal {
    String kind;//品种
    String color;//颜色

    public void eat(){
        System.out.println("动物要吃饭");
    }

    public void sleep(){
        System.out.println("动物都睡觉");
    }

}
