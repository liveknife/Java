package com.atguigu.a_object;

public class Citizen {
    String name, idCard;
    MyDate birthday = new MyDate();
}
