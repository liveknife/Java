package com.atguigu._private;

public class Demo01Private {
   public static void main(String[] args) {
      Person a = new Person();
      a.setName("王轴");
      System.out.println(a.getName());
   }
}
