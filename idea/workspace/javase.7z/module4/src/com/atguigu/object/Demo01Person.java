package com.atguigu.object;


public class Demo01Person {
    public static void main(String[] args) {
        Person person = new Person();
        person.name = "金莲";
        person.age = 18;
        person.eat();
    }
}
