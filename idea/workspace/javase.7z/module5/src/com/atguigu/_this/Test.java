package com.atguigu._this;

public class Test {
    public static void main(String[] args) {
        Person s = new Person();
        s.name = "小头儿子";
        s.speak("大头爸爸");
    }
}
