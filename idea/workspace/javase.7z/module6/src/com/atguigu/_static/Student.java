package com.atguigu._static;

public class Student {
    String name, classRoom;
    int age;
}
