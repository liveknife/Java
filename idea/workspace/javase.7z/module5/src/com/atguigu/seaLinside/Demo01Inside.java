package com.atguigu.seaLinside;

public class Demo01Inside {

}
