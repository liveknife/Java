package com.atguigu.twoArray;

public class Demo01TwoArray {
    public static void main(String[] args) {
        /*
        *
        * 数据类型[][] 数组名 = new 数据类型[m][n]
        * 数据类型 数组名[][] = new 数据类型[m][n]
        * 数据类型[] 数组名[] = new 数据类型[m][n]
        * m:代表的是二维数组的长度
        * n:代表的是二维数组中每一个一维数组的长度
        *
        * */

        // int[][] tArr = new int[3][3]; // 动态初始化
        // int tArr1[][] = new int[][]; // 动态初始化
        // int[] tArr2[] = new int[3][3]; // 动态初始化

        // int[][] tArr = new int[][]; // 静态初始化
        // int tArr1[][] = new int[][]; // 静态初始化
        // int[] tArr2[] = new int[][]; // 静态初始化

        // int[][] a = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}}; // 简化静态初始化
        // int a1[][] ={{1, 2, 3}, {4, 5, 6}, {7, 8, 9}}; // 简化静态初始化
        // int[] a2[] ={{1, 2, 3}, {4, 5, 6}, {7, 8, 9}}; // 简化静态初始化
    }
}
