package com.atguigu.a_object;

public class MyDate {
    int year, month, day;
}
