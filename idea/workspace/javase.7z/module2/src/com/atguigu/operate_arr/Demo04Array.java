package com.atguigu.operate_arr;

public class Demo04Array {
    public static void main(String[] args) {
        int[] arr = new int[3];
        System.out.println(arr);
        System.out.println(arr[1]);
        arr[1] = 100;
        System.out.println(arr[1]);
    }
}
 